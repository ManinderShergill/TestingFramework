package com.project.test.performance.tech;

/**
 * Hello world!
 *
 */
public class App {
	public static void main(String[] args) {
		System.out.println("Hello Performance Test!");
	}
}
